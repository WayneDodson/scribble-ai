export default async function handler(req, res) {
  if (req.method !== 'POST') {
    return res.status(405).json({ error: 'Method not allowed' });
  }

  const { prompt } = req.body;

  if (!prompt || typeof prompt !== 'string' || prompt.trim().length === 0) {
    return res.status(400).json({ error: 'A prompt is required' });
  }

  if (prompt.length > 500) {
    return res.status(400).json({ error: 'Prompt too long (max 500 characters)' });
  }

  const systemPrompt = `You are an MS Paint stick figure SVG artist. Output ONLY a raw SVG — no markdown, no explanation, no code fences. Just the SVG.

Rules:
- viewBox="0 0 800 450" (16:9)
- White background rect first: <rect width="800" height="450" fill="white"/>
- Stick figures: circle head (r=18-22, fill="white" stroke="black" stroke-width="3"), vertical line body, angled line arms, angled line legs. stroke="black" stroke-width="3"
- ALL lines slightly imperfect — use path with small wobbles or slightly off-angle lines to look hand-drawn
- Flat colours only: #e63946 red, #2196F3 blue, #4CAF50 green, #FF9800 orange, #9C27B0 purple, #000 black, #888 grey. No gradients
- Text: font-family="Arial, sans-serif" font-weight="bold" fill="black" font-size="16-22". Keep text short, funny, punchy
- Speech bubbles: white rect rx="8" with black stroke-width="2", text inside, small triangle pointer made with polygon fill="white" stroke="black"
- Simple objects: rectangles for computers/desks/signs, circles for wheels/eyes, triangles for shapes
- Red Xs, question marks, exclamation points for drama
- Lots of white space — breathe
- 3-6 characters or objects max. Don't crowd it
- Make it funny and expressive — wobbly lines, exaggerated poses, clear emotions
- Start with <svg and end with </svg> and nothing else`;

  try {
    const response = await fetch('https://api.anthropic.com/v1/messages', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'x-api-key': process.env.ANTHROPIC_API_KEY,
        'anthropic-version': '2023-06-01'
      },
      body: JSON.stringify({
        model: 'claude-sonnet-4-6',
        max_tokens: 1000,
        system: systemPrompt,
        messages: [{ role: 'user', content: `Draw this as an MS Paint stick figure SVG: ${prompt.trim()}` }]
      })
    });

    if (!response.ok) {
      const err = await response.json();
      console.error('Anthropic API error:', err);
      return res.status(502).json({ error: 'Failed to generate drawing' });
    }

    const data = await response.json();
    let svgText = data.content?.[0]?.text?.trim() ?? '';

    svgText = svgText.replace(/^```[a-z]*\n?/gi, '').replace(/\n?```$/gi, '').trim();
    const start = svgText.indexOf('<svg');
    const end = svgText.lastIndexOf('</svg>');
    if (start === -1 || end === -1) {
      return res.status(502).json({ error: 'Invalid SVG returned' });
    }
    svgText = svgText.slice(start, end + 6);

    res.setHeader('Content-Type', 'application/json');
    return res.status(200).json({ svg: svgText });

  } catch (err) {
    console.error('Server error:', err);
    return res.status(500).json({ error: 'Internal server error' });
  }
}
